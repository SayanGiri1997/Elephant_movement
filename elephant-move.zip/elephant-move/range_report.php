<?php 
include('header.php');
include('topnav.php');
include('menu.php');
?>


<div class="main-panel">
        <div class="content-wrapper" style="background-color: white;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>
              <div class="d-flex justify-content-between align-items-center">

                <!-- <div>
                  <h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Daily Elephant Movement Reports</h3>
                </div> -->

              </div>
            </div>
          </div>


    <!-- ===========Search=========== -->

            <form action="range_report.php" method="POST" enctype="multipart/form-data">
            <div class="col-md-12 m-0 p-3 border border-2 border-muted rounded">
            <h5 style="font-family: 'Roboto Condensed', sans-serif;"><b>Search Range Wise Report Date to Date :</b></h5>
            <div class="row">

            <div class="col-md-5">
            <input type="date" name="range_starting_date" class="form-control" <?php if(isset($_REQUEST['range_search'])){ ?> value="<?php echo $_REQUEST['range_starting_date']; ?>" <?php } ?> required>
            </div>

            <i><b>to</b></i>

            <div class="col-md-5">
            <input type="date" name="range_ending_date" class="form-control" <?php if(isset($_REQUEST['range_search'])){ ?> value="<?php echo $_REQUEST['range_ending_date']; ?>" <?php } ?> required>
            </div>

            <div class="col-md-1">
            <button type="submit" name="range_search" class="btn text-white" style="background-color: #4d9900;">Search</button>
            </div>

            </div>
            </div>
            </form>

          <!-- ============================ -->


  <?php 
    if(isset($_REQUEST['range_search'])){
    $starting_date=$_REQUEST['range_starting_date'];
    $ending_date=$_REQUEST['range_ending_date'];
    $marged_elephant_number=0;
  ?>

  <table class="table-bordered rounded table-responsive mt-2" cellspacing="0" cellpadding="0" width="100%" style="font-weight: bold;">
  <tr style="background-color: #77b300; font-family: 'Roboto Condensed', sans-serif; font-weight: bold;">
    <td style="width :3%;"><p align="center">Date</p></td>
    <td style="width :8%;" valign="center"><p align="center">Range</p></td>
    <td style="width :8%;" valign="center"><p align="center">No. of <br>Migratory<br> Elephants</p></td>
    <td style="width :8%;" valign="center"><p align="center">No. of <br>Residential<br> Elephant </p></td>
    <td style="width :8%;" valign="center"><p align="center">Total No. of<br> Elephant</p></td>
    <td style="width :6%;" valign="center"><p align="center">Elephant<br> days<br> starting<br> from<br> 10.01.2024<br> to till date</p></td>
  </tr>




   <!-- //==================Date Distinct Start===================// -->
   <?php
    $query="SELECT DISTINCT `date_time` FROM `elephant_area_details` WHERE `date_time`>='$starting_date' and `date_time`<='$ending_date' ORDER BY `date_time` ASC";
    $result=mysqli_query($con,$query);
    $rows=mysqli_num_rows($result);

    if($rows>0){
    while($datafetch=mysqli_fetch_array($result)){
    $distinct_date=$datafetch['date_time'];

    //==================Date Distinct End===================//
    ?>
  
  
  <tr>
    <td width="92"><p align="center"><?php echo $distinct_date; ?></p></td>

    <td colspan="6" valign="center">


  <table border="1" cellspacing="0" cellpadding="0" align="left"  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
      
      <tr>
      <td width="1121" valign="top">
    
      <table border="1" cellspacing="0" cellpadding="0" align="left"  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">

      <?php 
        //==================Range Distinct Start===================//

        $queryr="SELECT DISTINCT `range_id` FROM `elephant_area_details` WHERE `date_time`='$distinct_date' and `title_one`>'0' ORDER BY `range_id` ASC";
        $resultr=mysqli_query($con,$queryr);
        $total_elephant=0;
        while($datafetchr=mysqli_fetch_array($resultr)){
        $distinct_range_id=$datafetchr['range_id'];

        $query3="SELECT * FROM `mapping_table` WHERE `range_id`='$distinct_range_id'";
        $result3=mysqli_query($con,$query3);
        $datafetch3=mysqli_fetch_array($result3);
        $range_name=$datafetch3['range_name'];

        $query4="SELECT * FROM `elephant_area_details` WHERE `range_id`='$distinct_range_id' and `date_time`='$distinct_date' and   `title_one`>'0'";
        $result4=mysqli_query($con,$query4);
        while($datafetch4=mysqli_fetch_array($result4)){
        $mouza_id=$datafetch4['mouza_id'];
        $title_one=$datafetch4['title_one'];
        $title_two=$datafetch4['title_two'];
        $total_elephant += $title_one + $title_two;

        $query3m="SELECT * FROM `mapping_table` WHERE `mouza_id`='$mouza_id'";
          $result3m=mysqli_query($con,$query3m);
          $datafetch3m=mysqli_fetch_array($result3m);
          $mouza_name=$datafetch3m['mouza_name'];


      //==================Range Distinct End===================//

        ?>

    
          <tr>
            <td width="104"><p align="center"><?php echo $range_name.' ' .'('.$mouza_name.')'; ?></p></td>
            <td width="104"><p align="center"><?php echo $title_one; ?></p></td>
            <td width="104"><p align="center"><?php echo $title_two; ?></p></td>
            <td width="104"><p align="center"><?php echo $title_one + $title_two; ?> </p></td>
          </tr>

        <?php  } } ?>
      
      
      
          <tr>
            <td width="417" colspan="4" style="background-color: #77b300;" class="pr-2 pt-1"><p align="right">Total - <?php echo $total_elephant; ?></p></td>
          </tr>
      
        </table>
    </td>
        <td width="207" style="background-color: #80e5ff;"><p align="center">
          
          <?php
         $marged_elephant_number +=  $total_elephant;
          echo $marged_elephant_number; 
          ?>


        </p></td>
      </tr>
    </table>







    </td>
  </tr>

<?php
}
}
}
?>
</table>
</div>
</div>

<?php include('footer.php'); ?>
