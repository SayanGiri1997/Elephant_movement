<div class="container-fluid page-body-wrapper">
      <nav class="sidebar sidebar-offcanvas" id="sidebar" style="background-color: #003d99; font-family: 'Roboto Condensed', sans-serif;">
        <ul class="nav">
          <li class="nav-item rounded">
            <a class="nav-link" href="dashboard.php">
              <i class="ti-shield menu-icon text-white"></i>
              <span class="menu-title text-white">Dashboard</span>
            </a>
          </li>

<?php 
if($_SESSION['session_id']!='2021'){?>
          <li class="nav-item">
            <a href="range_list.php" class="nav-link">
              <i class="ti-palette menu-icon text-white"></i>
              <span class="menu-title text-white">Range List</span>
            </a>
          </li>
<?php }else{ ?>

<li class="nav-item">
            <a href="division_list.php" class="nav-link">
              <i class="ti-palette menu-icon text-white"></i>
              <span class="menu-title text-white">Division List</span>
            </a>
          </li>

<?php } ?>
		  

          <li class="nav-item">
            <a href="division_report.php" class="nav-link">
              <i class="ti-calendar menu-icon text-white"></i>
              <span class="menu-title text-white">Division Wise Reports</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="range_report.php" class="nav-link">
              <i class="ti-calendar menu-icon text-white"></i>
              <span class="menu-title text-white">Range Wise Reports</span>
            </a>
          </li>

          <!-- <li class="nav-item">
            <a href="beat_report.php" class="nav-link">
              <i class="ti-calendar menu-icon text-white"></i>
              <span class="menu-title text-white">Beat/Mouza Wise Reports</span>
            </a>
          </li> -->

          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="ti-power-off menu-icon text-white"></i>
              <span class="menu-title text-white">Log Out</span>
            </a>
          </li>

          
        </ul>
      </nav>