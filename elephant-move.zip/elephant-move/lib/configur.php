<?php
session_start();
// ob_start();

 $servername = "localhost";
 $username = "mchind_elephant_move";
 $password = "*sn*361975*";
 $db = "mchind_elephant_move";
    
try {
$con = mysqli_connect($servername, $username, $password, $db);
    }
catch(exception $e)
    {
 $e->getMessage();
    }
    return $con;
?>
