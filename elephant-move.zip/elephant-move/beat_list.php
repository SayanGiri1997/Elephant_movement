<?php 
include('header.php');
include('topnav.php');
include('menu.php');
$range_id=$_REQUEST['range_id'];
$qus=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_range` WHERE `r_id`='$range_id'"));
?>

<div class="main-panel">
        <div class="content-wrapper" style="background-color: white;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>
              <div class="d-flex justify-content-between align-items-center">

                <div>
                  <h4 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Division - <?php echo $dfetch1['dfo_name']; ?> > Range-<?php echo $qus['rangename'];?>  > Beat List</h4>
                </div>


                <!-- <div class="col-md-4">
                <div id="custom-search-input">
                <form action="" method="get" name="" enctype="multipart/form-data">
                <div class="input-group">
                    <input type="text" class="search-query form-control rounded border border-1 border-info" placeholder="Search The Beat" name="value" style="font-family: 'Nova Round', cursive;"  autocomplete="off" />
                    <span class="input-group-btn">
                        <button type="button" disabled>
                            <span class="fa fa-search"></span>
                        </button>
                    </span>
                </div>
                </form>
                </div></div> -->

              </div>
            </div>
          </div>

          <div class="row">

            <?php
              if(isset($_REQUEST['range_id']) && isset($_REQUEST['division_id']) && isset($_REQUEST['district_id'])){
               $range_id=$_REQUEST['range_id'];
               $division_id=$_REQUEST['division_id'];
               $district_id=$_REQUEST['district_id'];
              }

			 $query="SELECT DISTINCT `beat_id` FROM  `e_mapping_table`  WHERE `division_id`='$division_id' and `range_id`='$range_id'";
              $result=mysqli_query($con, $query);
			  $i=1;
			  if(mysqli_num_rows($result)>0){
              while($dfetch=mysqli_fetch_array($result)){

            ?>

            <div class="col-md-3 grid-margin stretch-card">
              <div class="card" style="background-color: #0C7230; border-radius: 10px;">
                <a href="mouza_list.php?range_id=<?php echo $range_id; ?>&district_id=<?php echo $district_id; ?>&division_id=<?php echo $division_id; ?>&beat_id=<?php echo $dfetch['beat_id']; ?>" style="text-decoration: none;">
                <div class="card-body py-4">
                  <!-- <p class="card-title text-md-center text-xl-left">no of Mouza - 123456</p> -->
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h4 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 text-white"><b><?php $beat_id=$dfetch['beat_id']; 
					$qus=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_beat` WHERE `b_id`='$beat_id'"));
					echo $qus['beat'];  ?></b></h4>
                    <i class="ti-calendar icon-md text-white mb-0 mb-md-3 mb-xl-0"></i>
                  </div>  
                  
                </div>
                </a>
              </div>
            </div>
			
			<?php 
			}
			}
			?>
          </div>
        </div>
      </div>

<?php include('footer.php'); ?>
