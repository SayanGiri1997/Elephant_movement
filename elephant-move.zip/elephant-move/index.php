<?php include('header1.php'); ?>

<?php 
//session_start();
// if(isset($_SESSION['session_id']) and isset($_SESSION['token_id']))
//     {
//       header('location:range_list.php');
//     }
?>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper bg-one d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-5 rounded shadow">
              <div class="brand-logo" align="center">
                <img src="img/logo.png" alt="logo" height="100" width="20">
				
				  <?php  if(isset($_SESSION['msg22'])){  echo $_SESSION['msg22'];  unset($_SESSION['msg22']); } ?> 
              </div>
			  
              <h4 align="center"><b>DEPARTMENT OF FOREST</b></h4>
              <h6 align="center" class="font-weight-light">Government of West Bengal</h6>
              <form class="pt-3" action="action/admin_login.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                  <input type="email" class="form-control form-control-sm rounded border border-secondary" name="el_user" id="exampleInputEmail1" placeholder="Username" autocomplete="off">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-sm rounded border border-secondary" name="el_pwd" id="exampleInputPassword1" placeholder="Password" autocomplete="off">
                </div>
                <div class="mt-3"> 
                  <button type="submit" class="btn btn-block btn-primary btn-md font-weight-medium auth-form-btn" name="elephant_submit"> LOGIN </button> 
                </div> 
                <!-- <div class="my-2 d-flex justify-content-between align-items-center">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      Keep me signed in
                    </label>
                  </div>
                  <a href="#" class="auth-link text-black">Forgot password?</a>
                </div> -->
                <!-- <div class="mb-2">
                  <button type="button" class="btn btn-block btn-facebook auth-form-btn">
                    <i class="ti-facebook mr-2"></i>Connect using facebook
                  </button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register.html" class="text-primary">Create</a>
                </div> -->
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
<?php include('footer.php'); ?>
