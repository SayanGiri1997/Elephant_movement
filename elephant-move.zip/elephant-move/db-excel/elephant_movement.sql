-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 05, 2024 at 07:45 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elephant_movement`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `division_id` varchar(250) DEFAULT NULL,
  `division_name` varchar(250) DEFAULT NULL,
  `user_id` varchar(250) DEFAULT NULL,
  `pwd` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `division_id`, `division_name`, `user_id`, `pwd`) VALUES
(1, '1', 'Bankura South', 'admin@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `elephant_area_details`
--

DROP TABLE IF EXISTS `elephant_area_details`;
CREATE TABLE IF NOT EXISTS `elephant_area_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `district_id` int DEFAULT NULL,
  `division_id` int DEFAULT NULL,
  `range_id` int DEFAULT NULL,
  `beat_id` int DEFAULT NULL,
  `mouza_id` int DEFAULT NULL,
  `title_one` varchar(250) DEFAULT NULL,
  `title_two` varchar(250) DEFAULT NULL,
  `date_time` date DEFAULT NULL,
  `time_stamp` timestamp NULL DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `long` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=218 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elephant_area_details`
--

INSERT INTO `elephant_area_details` (`id`, `district_id`, `division_id`, `range_id`, `beat_id`, `mouza_id`, `title_one`, `title_two`, `date_time`, `time_stamp`, `lat`, `long`) VALUES
(217, 1, 1, 1, 1, 10, 'rr', '4', '2024-02-01', '2024-02-01 03:21:20', '23.1856', '87.014'),
(216, 1, 1, 1, 1, 9, 'tt', '6', '2024-02-01', '2024-02-01 03:21:20', '23.1811', '86.9815'),
(215, 1, 1, 1, 1, 8, 'hh', '10', '2024-02-01', '2024-02-01 03:21:20', '23.2354', '86.9496'),
(214, 1, 1, 1, 1, 7, 'gg', '12', '2024-02-01', '2024-02-01 03:21:20', '23.166', '87.054'),
(213, 1, 1, 1, 1, 6, 'ff', '10', '2024-02-01', '2024-02-01 03:21:20', '23.1764', '87.068'),
(212, 1, 1, 1, 1, 5, 'ee', '55', '2024-02-01', '2024-02-01 03:21:20', '22.9272', '87.0134'),
(211, 1, 1, 1, 1, 4, 'dd', '44', '2024-02-01', '2024-02-01 03:21:20', '23.1853', '87.0544'),
(210, 1, 1, 1, 1, 3, 'cc', '33', '2024-02-01', '2024-02-01 03:21:20', '23.3637', '87.2978'),
(209, 1, 1, 1, 1, 2, 'bb', '22', '2024-02-01', '2024-02-01 03:21:20', '23.2126', '86.9756'),
(208, 1, 1, 1, 1, 1, 'aa', '11', '2024-02-01', '2024-02-01 03:21:20', '23.2154', '86.9832');

-- --------------------------------------------------------

--
-- Table structure for table `mapping_table`
--

DROP TABLE IF EXISTS `mapping_table`;
CREATE TABLE IF NOT EXISTS `mapping_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `district_id` int DEFAULT NULL,
  `district_name` varchar(250) DEFAULT NULL,
  `division_id` int DEFAULT NULL,
  `division_name` varchar(250) DEFAULT NULL,
  `range_id` int DEFAULT NULL,
  `range_name` varchar(250) DEFAULT NULL,
  `beat_id` int DEFAULT NULL,
  `beat_name` varchar(255) DEFAULT NULL,
  `mouza_id` int DEFAULT NULL,
  `mouza_name` varchar(255) DEFAULT NULL,
  `jl_no` varchar(255) DEFAULT NULL,
  `lat_area` varchar(255) DEFAULT NULL,
  `long_area` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mapping_table`
--

INSERT INTO `mapping_table` (`id`, `district_id`, `district_name`, `division_id`, `division_name`, `range_id`, `range_name`, `beat_id`, `beat_name`, `mouza_id`, `mouza_name`, `jl_no`, `lat_area`, `long_area`) VALUES
(1, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 1, 'Taribeterdihi', '159', '23.2154', '86.9832'),
(2, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 2, 'Siarbada', '133', '23.2126', '86.9756'),
(3, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 3, 'Dadhimukha', '189', '23.3637', '87.2978'),
(4, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 4, 'Chack-Jagadalla', '195', '23.1853', '87.0544'),
(5, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 5, 'Laxmi Jagard', '96', '22.9272', '87.0134'),
(6, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 6, 'Benajira', '60', '23.1764', '87.068'),
(7, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 7, 'Chegulia', '3', '23.166', '87.054'),
(8, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 8, 'Dhulidihi', '97', '23.2354', '86.9496'),
(9, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 9, 'Chelama', '144', '23.1811', '86.9815'),
(10, 1, 'COOCH BEHAR', 1, 'Bankura South', 1, 'Bankura', 1, 'Bankura', 10, 'Dhubraji', '152', '23.1856', '87.014');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
