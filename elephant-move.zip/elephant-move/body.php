<div class="main-panel">
<div class="content-wrapper" style="background-color: white;">
<div class="row">
<div class="col-md-12 grid-margin">
<center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100">
</div>
</div>
<div class="row">
<!--==================================For Map Pointing======================================== -->
<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/flag-icon-css/1.3.0/css/flag-icon.min.css">
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBciNFt_xYpjx_QaQZXKAyRJn7sLUwMPds"></script>
<!-- Also include jquery.min.js file -->
<!--==================================Map Pointing End======================================== -->
<div class="col-md-12">
<div class="card shadow" style="padding:1px; border: 1px solid #003380; border-radius:10px;">
<div id="mapa" style="height:63vh; width:auto; border-radius:10px;"></div>
</div>
</div>
<script type="text/javascript">
var map,
infowindow = null;
function initialize() {
    var latlng = new google.maps.LatLng(23.376551,87.736889); 
    var options = {
        zoom: 8.50,
        center: { lat: 23.376551, lng: 87.736889 },
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById("mapa"), options);
}
// Adds a marker to the map.
function addMarker(location, map, es) {
  // Add the marker at the clicked location, and add the next-available label
  // from the array of alphabetical characters.
  var marker = new google.maps.Marker({
    position: location,
    map: map,
    icon: 'img/elephant.png'
  });
    // Create the infowindow content, based on the country code
    var infowindow = new google.maps.InfoWindow({
        content: '<span>' + es + '</span>'
    });
    // Show the infowindow with the content, and the close it after 2 seconds
    google.maps.event.addListener(marker, 'click', function () {
        infowindow.open(map, marker);
        setTimeout(function () { infowindow.close(); }, 4000);
    });
}
// Initialize Map
initialize();
//===========For Elephant Pointing==============//
 <?php
 $date=date('Y-m-d');
 $query="SELECT * FROM `e_elephant_area` where `title_one`>0 and `date_time`='$date' ORDER BY `id` DESC";
 $result=mysqli_query($con,$query);
 while($datafetch=mysqli_fetch_array($result))
 {
  $title_one=$datafetch['title_one'];
  $title_two=$datafetch['title_two'];
  $mouza_id=$datafetch['mouza_id'];
  $district_id=$datafetch['district_id'];
  $division_id=$datafetch['division_id'];
  $range_id=$datafetch['range_id'];
  $beat_id=$datafetch['beat_id'];
  
  $datafetch1=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_mapping_table` WHERE `m_id`='$mouza_id'"));
  $district=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_district` WHERE `id`='$district_id'"));
  $division=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_dfo` WHERE `id`='$division_id'"));
  $range=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_range` WHERE `r_id`='$range_id'"));
  $beat=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_beat` WHERE `b_id`='$beat_id'"));
   
  $latlong=$datafetch1['lat_long'];
  $value=explode(",",$latlong);
?>
 addMarker({ lat: <?php echo $value['0']; ?> , lng: <?php echo $value['1']; ?>}, map,
  '<h5>Date : <b><?php echo $datafetch['date_time']; ?></b><br><br>  Mouza Name: <b><?php echo $datafetch1['mouza_name']; ?></b> <br><br> Beat Name: <b><?php echo $beat['beat']; ?></b> <br><br> Range Name: <b><?php echo $range['rangename']; ?></b><br><br> District Name: <b><?php echo $district['dis_name']; ?></b> <br><br>  Division Name: <b><?php echo $division['dfo_name']; ?></b> <br><br> Total No of Elephant : <b><?php echo $title_one + $title_two ?></b></h5>'); 
<?php 
} 
?>
// =====================================================
</script>
</div>
</div>
</div>