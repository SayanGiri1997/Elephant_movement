-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 18, 2024 at 06:08 AM
-- Server version: 5.7.41
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mchind_elephant_move`
--

-- --------------------------------------------------------

--
-- Table structure for table `e_beat`
--

CREATE TABLE `e_beat` (
  `b_id` int(11) NOT NULL,
  `beat` varchar(255) NOT NULL,
  `b_beat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_beat`
--

INSERT INTO `e_beat` (`b_id`, `beat`, `b_beat`) VALUES
(1, 'ARABARI', ''),
(2, 'ARABARI-SOCIO-ECO', ''),
(3, 'DAKSHINSOLE', ''),
(4, 'GOPALBANDH', ''),
(5, 'MIRGA', ''),
(6, 'BHADUTALA', ''),
(7, 'MOUPAL', ''),
(8, 'CHANDRA', '');

-- --------------------------------------------------------

--
-- Table structure for table `e_dfo`
--

CREATE TABLE `e_dfo` (
  `id` int(11) NOT NULL,
  `dfo_name` varchar(100) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `dfo_add` varchar(255) DEFAULT NULL,
  `dfo_email` varchar(50) DEFAULT NULL,
  `dfo_mobile` varchar(50) DEFAULT NULL,
  `dfo_phone` varchar(50) DEFAULT NULL,
  `dfo_userid` varchar(100) DEFAULT NULL,
  `dfo_pass` varchar(100) DEFAULT NULL,
  `cr_date` datetime DEFAULT NULL,
  `mo_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_dfo`
--

INSERT INTO `e_dfo` (`id`, `dfo_name`, `designation`, `dfo_add`, `dfo_email`, `dfo_mobile`, `dfo_phone`, `dfo_userid`, `dfo_pass`, `cr_date`, `mo_date`) VALUES
(1, 'BTR (E)', '', 'Amtala College Halt, Alipurduar, Jalpaiguri-736122', '', '', '', '', '', NULL, '2019-08-21 03:50:28'),
(3, 'BTR(W)', '', 'Alipurduar Court, Alipurduar-736121', '', '', '', '', '', NULL, '2021-08-09 04:19:39'),
(5, 'Bankura(N)', '', 'Bankura, PIN:722101', '', '', '', '', '', NULL, '2017-11-09 02:17:21'),
(6, 'Bankura(S)', '', 'Bankura, PIN:722102', '', '', '', '', '', NULL, '2017-11-09 02:17:57'),
(7, 'Panchet', '', 'Bishnupur, Bankura, PIN: 722122', '', '', '', '', '', NULL, '2017-11-09 02:43:27'),
(8, 'Burdwan', '', 'Golapbag,  Burdwan, PIN: 713 104', '', '', '', '', '', NULL, '2021-08-09 04:13:46'),
(9, 'Durgapur', '', 'astri Avenue, Aranya Pally, Durgapur, Burdwan, PIN: 713212', '', '', '', '', '', NULL, '2017-11-09 02:44:22'),
(10, 'Howrah', '', 'Stadium Complex, G.T. Road, Dalmia Park, Shibpur, Howrah-711101\r\n', '', '', '', '', '', NULL, '2019-02-28 23:11:38'),
(12, 'Jalpaiguri', '', 'Hakimpara, Jalpaiguri, PIN-735101', '', '', '', '', '', NULL, '2017-11-09 03:01:14'),
(13, 'Malda', '', 'Nazrul Sarani, Malda- 732101\r\n', '', '', '', '', '', NULL, '2017-11-09 03:02:02'),
(14, 'Raiganj', '', 'Karhahjora, Uttar Dinajpur-733130\r\n', '', '', '', '', '', NULL, '2017-11-09 03:02:33'),
(15, 'Purba Medinipur', '', 'Chachamina, Tamluk, Purba Medinipur, PIN: 721636', '', '', '', '', '', NULL, '2017-11-09 03:03:18'),
(16, 'Jhargram', '', 'Jhargram, Paschim Medinipur, PIN: 721502         ', '', '', '', '', '', NULL, '2017-11-09 03:06:20'),
(17, 'Kharagpur', '', 'Hijli Co Operative, Kharagpur, Paschim Medinipur, PIN: 721306', '', '', '', '', '', NULL, NULL),
(18, 'Medinipur', '', 'Midnapur, Paschim Midnapur-721101', 'medinipur@gmail.com', '', '', '', '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-09 03:14:56'),
(20, 'North 24 PGN', '', 'KK Mitra Rd, Near Barasat Bus Stand, Champadali, Barasat-700124', '', '', '', '', '', NULL, '2019-02-28 23:12:39'),
(21, 'South 24 PGN', '', 'New Administrative Building, 4th Floor, Alipore-700027', '', '', '', '', '', NULL, '2018-09-24 23:05:33'),
(22, 'STR', '', 'Canning Town, District: 24-Paraganas (South), PIN: 743329', '', '', '', '', '', NULL, '2017-11-09 03:23:40'),
(23, 'Nadia-Murshidabad', '', 'Krishnagar, Nadia-741101', '', '', '', '', '', NULL, NULL),
(24, 'Purulia', '', 'Purulia, PIN: 723101', '', '', '', '', '', NULL, '2017-11-09 03:25:26'),
(25, 'Kangsabati(N)', '', 'Purulia, PIN: 723102', '', '', '', '', '', NULL, '2017-11-09 03:25:59'),
(26, 'Kangsabati(S)', '', 'Raghabpur North Lake Road, Purulia, PIN: 723101', '', '', '', '', '', NULL, '2017-11-09 03:26:23'),
(27, 'Coochbehar', '', 'Kameswari Road (East), Coochbehar-736101', '', '', '', '', '', NULL, '2017-11-09 03:29:33'),
(28, 'Darjeeling', '', 'Barakakjhora, Darjeeling-734101\r\n', '', '', '', '', '', NULL, '2021-08-09 04:15:28'),
(30, 'Kalimpong', '', 'Kalimpong, Darjeeling-734301', '', '', '', '', '', NULL, '2017-11-09 03:31:06'),
(36, 'UTILIZATION', '', 'Mitra Building, 3rd Floor, Lyans Range, Kolkata-700001', '', '', '', '', '', '2021-09-01 00:00:00', '2021-09-01 00:00:00'),
(2021, 'Super Admin', '', 'Admin', 'admin@gmail.com', '', '', '', '827ccb0eea8a706c4c34a16891f84e7b', '2021-09-29 10:02:17', '2021-09-07 10:02:17'),
(2027, 'Jaldapara WLD', '', 'Nilkuthi, Coochbehar-736101', '', '', '', '', '', NULL, '2021-10-05 01:56:36'),
(2028, 'Birbhum', '', 'Suri, Birbhum, PIN: 731101', '', '', '', '', '', NULL, '2021-10-05 02:20:35'),
(2029, 'Rupnarayan', '', 'Rangamati, Vidyasagar University, Paschim Medinipur, PIN: 721101', '', '', '', '', '', NULL, '2021-10-05 02:34:20'),
(2030, 'Kurseong', '', 'Dowhill, Kurseong', '', '', '', '', '', NULL, '2021-10-05 02:34:58'),
(2031, 'Baikunthapur', '', 'Rabindra Nagar, Rabindra Sarani, Siliguri-734006 ', '', '', '', '', '', NULL, '2021-10-28 03:51:13'),
(2079, 'Kangsabati (North)  Division', '', 'Raghabpur North Lake Road, Purulia, PIN:723101', '', '', '', '', '', NULL, '2024-02-19 07:02:18');

-- --------------------------------------------------------

--
-- Table structure for table `e_district`
--

CREATE TABLE `e_district` (
  `id` int(11) NOT NULL,
  `dis_name_b` varchar(555) DEFAULT NULL,
  `dis_name` varchar(100) DEFAULT NULL,
  `short_form` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_district`
--

INSERT INTO `e_district` (`id`, `dis_name_b`, `dis_name`, `short_form`) VALUES
(1, 'à¦†à¦²à¦¿à¦ªà§à¦°à¦¦à§à§Ÿà¦¾à¦°', 'Alipurduar', 'APD'),
(2, 'à¦¬à¦¾à¦à¦•à§à¦¡à¦¼à¦¾', 'Bankura', 'BNK'),
(3, 'à¦ªà¦¶à§à¦šà¦¿à¦® à¦¬à¦°à§à¦§à¦®à¦¾à¦¨', 'Paschim Bardhaman', 'WBN'),
(4, 'à¦¬à§€à¦°à¦­à§‚à¦®', 'Birbhum', 'BIR'),
(5, 'à¦•à§‹à¦šà¦¬à¦¿à¦¹à¦¾à¦°', 'Coochbehar', 'COB'),
(6, 'à¦¦à¦¾à¦°à§à¦œà§€à¦²à¦¿à¦‚', 'Darjeeling', 'DAR'),
(7, 'à¦¹à§à¦—à¦²à§€', 'Hoogly', 'HLY'),
(8, 'à¦œà¦²à¦ªà¦¾à¦‡à¦—à§à¦¡à¦¼à¦¿', 'Jalpaiguri', 'JPG'),
(9, 'à¦®à¦¾à¦²à¦¦à¦¾	', 'Malda', 'MLD'),
(10, 'à¦®à§à¦°à§à¦¶à¦¿à¦¦à¦¾à¦¬à¦¾à¦¦', 'Murshidabad', 'MBD'),
(11, 'à¦¨à¦¦à§€à§Ÿà¦¾	', 'Nadia', 'NAD'),
(12, 'à¦‰à¦¤à§à¦¤à¦° à§¨à§ª à¦ªà¦°à¦—à¦£à¦¾', 'North 24 Parganas', 'NTP'),
(13, 'à¦ªà¦¶à§à¦šà¦¿à¦® à¦®à§‡à¦¦à¦¿à¦¨à§€à¦ªà§à¦°	', 'Paschim Medinipur', 'WMD'),
(14, 'à¦ªà§‚à¦°à§à¦¬à§à¦¬ à¦®à§‡à¦¦à¦¿à¦¨à§€à¦ªà§à¦°	', 'Purba Medinipur', 'EMD'),
(15, 'à¦ªà§à¦°à§à¦²à¦¿à§Ÿà¦¾', 'Purulia', 'PUR'),
(16, 'à¦¦à¦•à§à¦·à¦¿à¦£ à§¨à§ª à¦ªà¦°à¦—à¦£à¦¾', 'South 24 Parganas', 'STP'),
(17, 'à¦‰à¦¤à§à¦¤à¦° à¦¦à¦¿à¦¨à¦¾à¦œà¦ªà§à¦°', 'Uttar Dinajpur', 'NDP'),
(19, NULL, 'Forest Modal District', NULL),
(20, 'à¦•à§‹à¦²à¦•à¦¾à¦¤à¦¾	', 'KOLKATA', 'KOL'),
(21, 'à¦¹à¦¾à¦“à¦¡à¦¼à¦¾', 'Howrah', 'HWH'),
(23, 'à¦à¦¾à¦¡à¦¼à¦—à§à¦°à¦¾à¦®', 'Jhargram', 'JHG'),
(25, 'à¦ªà§‚à§à¦°à§à¦¬ à¦¬à¦°à§à¦§à¦®à¦¾à¦¨', 'Purba Burdwan', 'EBN'),
(26, 'à¤•à¤¾à¤²à¤¿à¤®à¥à¤ªà¥‹à¤‚à¤—', 'Kalimpong', 'KPG'),
(27, 'à¦¦à¦•à§à¦·à¦¿à¦£ à¦¦à¦¿à¦¨à¦¾à¦œà¦ªà§à¦°', 'Dakshin Dinajpur', 'SDP');

-- --------------------------------------------------------

--
-- Table structure for table `e_elephant_area`
--

CREATE TABLE `e_elephant_area` (
  `id` int(11) NOT NULL,
  `district_id` int(11) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL,
  `range_id` int(11) DEFAULT NULL,
  `beat_id` int(11) DEFAULT NULL,
  `mouza_id` int(11) DEFAULT NULL,
  `title_one` int(11) DEFAULT NULL,
  `title_two` int(11) DEFAULT NULL,
  `date_time` date DEFAULT NULL,
  `time_stamp` timestamp NULL DEFAULT NULL,
  `lat_long` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_elephant_area`
--

INSERT INTO `e_elephant_area` (`id`, `district_id`, `division_id`, `range_id`, `beat_id`, `mouza_id`, `title_one`, `title_two`, `date_time`, `time_stamp`, `lat_long`) VALUES
(353, 13, 18, 1, 3, 41, 20, 0, '2024-03-06', '2024-03-05 20:25:45', '22.59011935,87.36311733'),
(354, 13, 18, 1, 3, 45, 30, 0, '2024-03-06', '2024-03-05 20:25:45', '22.60138735,87.31832371'),
(355, 13, 18, 2, 6, 87, 30, 0, '2024-03-06', '2024-03-05 20:26:30', '22.48548008,87.32735975'),
(356, 13, 18, 1, 1, 1, 12, 1, '2024-03-06', '2024-03-05 22:10:24', '22.69628062,87.34564748'),
(357, 13, 18, 2, 7, 110, 24, 0, '2024-03-06', '2024-03-05 22:10:46', '22.48668337,87.27936583'),
(358, 13, 18, 1, 1, 1, 12, 0, '2024-03-14', '2024-03-14 06:28:59', '22.69628062,87.34564748'),
(359, 13, 18, 1, 1, 2, 10, 0, '2024-03-14', '2024-03-14 06:28:59', '22.68939122,87.3969349'),
(360, 13, 18, 1, 1, 2, 34, 0, '2024-03-18', '2024-03-17 22:35:54', '22.68939122,87.3969349'),
(361, 13, 18, 3, 8, 141, 24, 0, '2024-03-18', '2024-03-17 22:37:16', '22.48333838,87.14710243'),
(362, 13, 18, 3, 8, 153, 12, 0, '2024-03-18', '2024-03-17 22:37:16', '22.44771661,87.19031839');

-- --------------------------------------------------------

--
-- Table structure for table `e_mapping_table`
--

CREATE TABLE `e_mapping_table` (
  `m_id` int(11) NOT NULL,
  `district_id` int(11) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL,
  `range_id` int(11) DEFAULT NULL,
  `beat_id` int(11) DEFAULT NULL,
  `mouza_name` varchar(255) DEFAULT NULL,
  `jl_no` varchar(255) DEFAULT NULL,
  `lat_long` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_mapping_table`
--

INSERT INTO `e_mapping_table` (`m_id`, `district_id`, `division_id`, `range_id`, `beat_id`, `mouza_name`, `jl_no`, `lat_long`) VALUES
(1, 13, 18, 1, 1, 'ARABARI', '452', '22.69628062,87.34564748'),
(2, 13, 18, 1, 1, 'BELMA', '692', '22.68939122,87.3969349'),
(3, 13, 18, 1, 1, 'BURAMARA', '688', '22.6862945,87.3700919'),
(4, 13, 18, 1, 1, 'BURISOL', '677', '22.68549684,87.35945547'),
(5, 13, 18, 1, 1, 'CHANDMURA', '451', '22.6783949,87.34306643'),
(6, 13, 18, 1, 1, 'GARANGA', '676', '22.69715591,87.35604298'),
(7, 13, 18, 1, 1, 'HIJALKOLA', '696', '22.67884132,87.40395123'),
(8, 13, 18, 1, 1, ' KELAMI', '690', '22.69812097,87.39749548'),
(9, 13, 18, 1, 1, 'KUCHASHIMUL', '683', '22.69495766,87.36795882'),
(10, 13, 18, 1, 1, 'MANGALBANDI', '682', '22.69180689,87.36337625'),
(11, 13, 18, 1, 1, 'NEPURA', '686', '22.68598784,87.38689243'),
(12, 13, 18, 1, 1, 'NISCHINTAPUR', '697', '22.67151536,87.40557711'),
(13, 13, 18, 1, 1, 'SATSOL', '18', '22.67183439,87.38233567'),
(14, 13, 18, 1, 1, 'SHYAMPUR', '695', '22.68325594,87.40252918'),
(15, 13, 18, 1, 1, 'TILAKHULA', '678', '22.69092609,87.35679198'),
(16, 13, 18, 1, 2, 'BAZARARARA', '64', '22.62788238,87.37553833'),
(17, 13, 18, 1, 2, 'BHANDARIA', '12', '22.64033601,87.37065553'),
(18, 13, 18, 1, 2, 'CHANDIPUR', '57', '22.6143724,87.38248068'),
(19, 13, 18, 1, 2, ' CHANDMURA', '1', '22.67053348,87.33614175'),
(20, 13, 18, 1, 2, ' DARKHOLA', '58', '22.61787304,87.38660828'),
(21, 13, 18, 1, 2, ' DOTAL', '67', '22.61802541,87.35950838'),
(22, 13, 18, 1, 2, ' GARARARA', '63', '22.62329737,87.37313782'),
(23, 13, 18, 1, 2, ' GHUCHISOL', '6', '22.64875413,87.34147838'),
(24, 13, 18, 1, 2, ' GOPALBANDH', '13', '22.64150366,87.38049238'),
(25, 13, 18, 1, 2, 'GUTIAMARA', '11', '22.65259206,87.36737169'),
(26, 13, 18, 1, 2, 'INDKURI', '62', '22.62373701,87.37958328'),
(27, 13, 18, 1, 2, ' JORAKEUNDI', '10', '22.63253995,87.3585854'),
(28, 13, 18, 1, 2, ' JOYPUR', '61', '22.62918578,87.38645838'),
(29, 13, 18, 1, 2, 'JUNPARA', '65', '22.61890607,87.36578566'),
(30, 13, 18, 1, 2, ' KUSUMDAHARI', '5', '22.64359372,87.33941735'),
(31, 13, 18, 1, 2, ' MAHISHDUBI', '2', '22.66818085,87.35363997'),
(32, 13, 18, 1, 2, 'MAJHIGAR', '15', '22.66543884,87.38162796'),
(33, 13, 18, 1, 2, 'PALTAGAR', '32', '22.63983878,87.41615817'),
(34, 13, 18, 1, 2, ' SAKHISOL', '3', '22.66145989,87.33870546'),
(35, 13, 18, 1, 2, ' SANKRUI', '16', '22.65451089,87.39392355'),
(36, 13, 18, 1, 2, 'SAPADIHA', '17', '22.66030671,87.39617001'),
(37, 13, 18, 1, 2, 'URAMI', '4', '22.6508626,87.33888325'),
(38, 13, 18, 1, 3, ' BANKIBANDH', '422', '22.59643846,87.34180632'),
(39, 13, 18, 1, 3, 'BANSBADI', '421', '22.60670157,87.35064369'),
(40, 13, 18, 1, 3, 'DAKSHINSOL', '431', '22.60009982,87.32313795'),
(41, 13, 18, 1, 3, 'DUDIABANDI', '74', '22.59011935,87.36311733'),
(42, 13, 18, 1, 3, 'GOBARDDA', '75', '22.58260185,87.35925127'),
(43, 13, 18, 1, 3, 'KHARGADIHA', '68', '22.59571913,87.3592925'),
(44, 13, 18, 1, 3, 'KONTAI', '72', '22.59442631,87.37076144'),
(45, 13, 18, 1, 3, 'SHALDAHARA', '426', '22.60138735,87.31832371'),
(46, 13, 18, 1, 3, 'TUREPARA', '420', '22.61169677,87.34251275'),
(47, 13, 18, 1, 3, 'TYANGRASOL', '412', '22.61079286,87.31558331'),
(48, 13, 18, 1, 4, 'DHARASOL', '38', '22.63553257,87.42859436'),
(49, 13, 18, 1, 4, 'DOGERYA', '40', '22.61918075,87.41970037'),
(50, 13, 18, 1, 4, 'MAHARAJPUR', '19', '22.66951079,87.41706115'),
(51, 13, 18, 1, 4, 'TORIA', '26', '22.6577266,87.42283038'),
(52, 13, 18, 1, 5, 'BAGALDOBA', '161', '22.63997787,87.24903192'),
(53, 13, 18, 1, 5, 'BAGPICHULA', '279', '22.61100519,87.24058621'),
(54, 13, 18, 1, 5, 'BANAMALIPUR', '332', '22.62708669,87.27533248'),
(55, 13, 18, 1, 5, 'BANSHKONA', '323', '22.60476598,87.26415481'),
(56, 13, 18, 1, 5, 'BARAKULI', '398', '22.64417918,87.30692401'),
(57, 13, 18, 1, 5, 'BELDANGARI', '349', '22.65580805,87.25615798'),
(58, 13, 18, 1, 5, 'BENEGERE', '274', '22.61814004,87.22225597'),
(59, 13, 18, 1, 5, 'BHALUKSOL', '162', '22.63980918,87.2258097'),
(60, 13, 18, 1, 5, 'BHANGABANDH', '334', '22.61394701,87.27869507'),
(61, 13, 18, 1, 5, 'BHURRUCHATI', '327', '22.60391652,87.26855634'),
(62, 13, 18, 1, 5, 'BULANPUR', '396', '22.64645772,87.29048745'),
(63, 13, 18, 1, 5, 'CHAKAJHARIA', '158', '22.63972237,87.21025483'),
(64, 13, 18, 1, 5, 'CHHARDALAL', '280', '22.59797074,87.22969247'),
(65, 13, 18, 1, 5, 'CHUNPARA', '351', '22.65550144,87.23866031'),
(66, 13, 18, 1, 5, 'DHABANI', '346', '22.64851418,87.26871444'),
(67, 13, 18, 1, 5, 'DHANGHORI CHHOTA', '336', '22.64416685,87.26031684'),
(68, 13, 18, 1, 5, 'DURGADASPUR', '397', '22.64320577,87.29402261'),
(69, 13, 18, 1, 5, 'GAIGHATA', '403', '22.63898618,87.30885183'),
(70, 13, 18, 1, 5, 'GOTKOLA', '395', '22.64956393,87.30203898'),
(71, 13, 18, 1, 5, 'HEMSAGAR', '342', '22.65047122,87.28652315'),
(72, 13, 18, 1, 5, 'JAGANNATHPUR', '341', '22.6499411,87.27843581'),
(73, 13, 18, 1, 5, 'JORAKUSHMI', '347', '22.6447956,87.26615099'),
(74, 13, 18, 1, 5, 'JORAKUSUMI', '275', '22.6235058,87.2313889'),
(75, 13, 18, 1, 5, 'KALYANPUR', '338', '22.64164344,87.27972993'),
(76, 13, 18, 1, 5, 'KATALKULI', '326', '22.60789776,87.26730594'),
(77, 13, 18, 1, 5, 'KHARIGERE', '339', '22.64167296,87.28290462'),
(78, 13, 18, 1, 5, 'MAHARAJPUR', '343', '22.65144351,87.280543'),
(79, 13, 18, 1, 5, 'MIRGA', '340', '22.63514117,87.29004587'),
(80, 13, 18, 1, 5, 'PIRRALOHA', '405', '22.62938612,87.28449866'),
(81, 13, 18, 1, 5, 'RAMCHANDRAPUR', '345', '22.65086876,87.26879223'),
(82, 13, 18, 1, 5, 'RAMNAGAR', '159', '22.64499518,87.2228471'),
(83, 13, 18, 1, 5, 'SARASBEDIA', '350', '22.65423494,87.25147149'),
(84, 13, 18, 1, 5, 'TILABONI', '154', '22.6523356,87.22754545'),
(85, 13, 18, 1, 5, 'TUNGNI', '276', '22.62275832,87.24290138'),
(86, 13, 18, 1, 5, 'TUSHPHELA', '160', '22.64618933,87.22996273'),
(87, 13, 18, 2, 6, 'BAHARKALABERYA', '514', '22.48548008,87.32735975'),
(88, 13, 18, 2, 6, 'BALIJURI', '512', '22.4882463,87.33237314'),
(89, 13, 18, 2, 6, 'BANKAJETA', '511', '22.49220235,87.33604362'),
(90, 13, 18, 2, 6, 'BHABRIGERE', '518', '22.50515993,87.31590522'),
(91, 13, 18, 2, 6, 'BHALUKKHULYA', '165', '22.46135838,87.31451792'),
(92, 13, 18, 2, 6, 'CHAKSRINATH', '500', '22.49421422,87.28604796'),
(93, 13, 18, 2, 6, 'CHANDUA', '525', '22.5007418,87.35018871'),
(94, 13, 18, 2, 6, 'DHANYASAULA', '502', '22.47886922,87.30162938'),
(95, 13, 18, 2, 6, 'DHOBASOL', '517', '22.49541034,87.30831413'),
(96, 13, 18, 2, 6, 'JAMBANI', '519', '22.50854153,87.32126943'),
(97, 13, 18, 2, 6, ' KALABERYA BHADUTALA', '515', '22.48873266,87.32334497'),
(98, 13, 18, 2, 6, 'KARNAGAR', '524', '22.51043129,87.34702304'),
(99, 13, 18, 2, 6, 'KHASJANGAL', '513', '22.49696069,87.3349882'),
(100, 13, 18, 2, 6, 'KISMAT BANKATI', '523', '22.50721406,87.33543011'),
(101, 13, 18, 2, 6, 'KOREDAN', '503', '22.46758778,87.30510673'),
(102, 13, 18, 2, 6, 'KRISHNANAGAR', '499', '22.49922941,87.29003492'),
(103, 13, 18, 2, 6, 'KUKURAKHUPI', '237', '22.48628808,87.28799228'),
(104, 13, 18, 2, 6, 'NISCHINTAPUR', '516', '22.48929843,87.31649913'),
(105, 13, 18, 2, 6, 'PIRCHAK', '501', '22.48219903,87.29221367'),
(106, 13, 18, 2, 6, 'SONAKARA', '236', '22.47326622,87.29352116'),
(107, 13, 18, 2, 7, 'BAGMARI', '240', '22.5040731,87.28265613'),
(108, 13, 18, 2, 7, 'BALISOL', '193', '22.52263366,87.21213636'),
(109, 13, 18, 2, 7, 'BARAPATHER KUMKUMI', '221', '22.5026032,87.27164156'),
(110, 13, 18, 2, 7, 'CHANDRA', '238', '22.48668337,87.27936583'),
(111, 13, 18, 2, 7, 'CHANIPUR', '253', '22.539073,87.21799976'),
(112, 13, 18, 2, 7, 'CHENGASOL', '250', '22.53634296,87.22809843'),
(113, 13, 18, 2, 7, 'CHHOTAPATHAR KUMKUMI', '224', '22.50769514,87.26445665'),
(114, 13, 18, 2, 7, 'DAHA', '212', '22.48963765,87.21131611'),
(115, 13, 18, 2, 7, 'GARMAL', '214', '22.49111556,87.2349232'),
(116, 13, 18, 2, 7, 'JARA', '218', '22.51865195,87.2477461'),
(117, 13, 18, 2, 7, 'JORAKUSHMA', '222', '22.49953727,87.27309715'),
(118, 13, 18, 2, 7, 'KARAMARASOL URF KALIBASA', '215', '22.50948951,87.23293644'),
(119, 13, 18, 2, 7, 'KHARIKACHATI', '213', '22.49413616,87.22776136'),
(120, 13, 18, 2, 7, 'KHARIKASULI', '232', '22.46778498,87.26542384'),
(121, 13, 18, 2, 7, 'KHASJANGAL', '227', '22.49242688,87.26015134'),
(122, 13, 18, 2, 7, 'MURKATI', '251', '22.53783897,87.22486698'),
(123, 13, 18, 2, 7, 'NANASOL', '196', '22.50531461,87.2123383'),
(124, 13, 18, 2, 7, 'NUTANDIHI', '194', '22.53395329,87.22002873'),
(125, 13, 18, 2, 7, 'PARUABAND', '195', '22.52585876,87.22818675'),
(126, 13, 18, 2, 7, 'PENCHAPARA', '219', '22.51730161,87.25666197'),
(127, 13, 18, 2, 7, 'SAORA', '235', '22.47494548,87.27929514'),
(128, 13, 18, 2, 7, 'SIJGOT(DARIMASOL)', '197', '22.49932895,87.22114079'),
(129, 13, 18, 2, 7, 'SUSNIBARI', '223', '22.50064626,87.27002313'),
(130, 13, 18, 2, 7, 'TARASULI', '225', '22.51418163,87.25966366'),
(131, 13, 18, 3, 8, 'AMAJHARNA', '61', '22.51003369,87.16182442'),
(132, 13, 18, 3, 8, 'ARJJUNBANDH', '98', '22.45742827,87.16895577'),
(133, 13, 18, 3, 8, 'BARAMCHATI', '99', '22.44778675,87.17732217'),
(134, 13, 18, 3, 8, 'BENASULI', '75', '22.46002055,87.15894068'),
(135, 13, 18, 3, 8, 'BHALUKKHULYA', '63', '22.48035763,87.1756234'),
(136, 13, 18, 3, 8, 'BHURKUNDISOL', '210', '22.48016597,87.19920543'),
(137, 13, 18, 3, 8, 'DAINMARI', '68', '22.46565772,87.17295633'),
(138, 13, 18, 3, 8, 'DHAPRA', '211', '22.47672061,87.20396642'),
(139, 13, 18, 3, 8, 'DHARASOL', '62', '22.481063,87.16491087'),
(140, 13, 18, 3, 8, 'DUMURKATA', '64', '22.48091784,87.18637058'),
(141, 13, 18, 3, 8, 'HARINKANALI', '58', '22.48333838,87.14710243'),
(142, 13, 18, 3, 8, 'HATIASOL', '65', '22.46530202,87.19296606'),
(143, 13, 18, 3, 8, 'JHARIA', '60', '22.49280615,87.15283749'),
(144, 13, 18, 3, 8, 'KESHESOL', '70', '22.46794024,87.15955541'),
(145, 13, 18, 3, 8, 'KHARIKASULI', '69', '22.46067703,87.16552368'),
(146, 13, 18, 3, 8, 'LAKSHMICHAK', '209', '22.47240618,87.19837899'),
(147, 13, 18, 3, 8, 'LALITASOL', '118', '22.45074268,87.19674628'),
(148, 13, 18, 3, 8, 'MOHANPUR', '71', '22.47086669,87.15062924'),
(149, 13, 18, 3, 8, 'NUNIACHATRI', '67', '22.47047316,87.17699645'),
(150, 13, 18, 3, 8, 'PARURAYMA', '204', '22.50186772,87.17239138'),
(151, 13, 18, 3, 8, 'PUKHURIASOL', '205', '22.49373945,87.17236865'),
(152, 13, 18, 3, 8, 'PUTKI', '57', '22.46917121,87.14280685'),
(153, 13, 18, 3, 8, 'SARENGASOL', '116', '22.44771661,87.19031839'),
(154, 13, 18, 3, 8, 'SUKNAKHALI', '119', '22.46402454,87.20184115'),
(155, 13, 18, 3, 8, 'TAMAKBARI', '117', '22.455649,87.19217194');

-- --------------------------------------------------------

--
-- Table structure for table `e_range`
--

CREATE TABLE `e_range` (
  `r_id` int(11) NOT NULL,
  `rangename` varchar(255) NOT NULL,
  `b_rangename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `e_range`
--

INSERT INTO `e_range` (`r_id`, `rangename`, `b_rangename`) VALUES
(1, 'ARABARI', ''),
(2, 'BHADUTALA', ''),
(3, 'CHANDRA', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `e_beat`
--
ALTER TABLE `e_beat`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `e_dfo`
--
ALTER TABLE `e_dfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_district`
--
ALTER TABLE `e_district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_elephant_area`
--
ALTER TABLE `e_elephant_area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_mapping_table`
--
ALTER TABLE `e_mapping_table`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `e_range`
--
ALTER TABLE `e_range`
  ADD PRIMARY KEY (`r_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `e_beat`
--
ALTER TABLE `e_beat`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `e_dfo`
--
ALTER TABLE `e_dfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2080;

--
-- AUTO_INCREMENT for table `e_district`
--
ALTER TABLE `e_district`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `e_elephant_area`
--
ALTER TABLE `e_elephant_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=363;

--
-- AUTO_INCREMENT for table `e_mapping_table`
--
ALTER TABLE `e_mapping_table`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `e_range`
--
ALTER TABLE `e_range`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
