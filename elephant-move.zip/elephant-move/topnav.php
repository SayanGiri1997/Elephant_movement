<?php 
if($_SESSION['session_id']){
  $division_id=$_SESSION['session_id'];
}
?>

<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" style="z-index: 99999; box-shadow: 1px 0px 0px 1px #005ce6;">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center" style="background-color: #005ce6;">
       <a href="range_list.php"><img src="img/logo.png" height="54" class="rounded shadow mx-2 p-1" style="border: 1px solid white;"></a><br>
      </div>

      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="background-color: #005ce6;">
        <button class="navbar-toggler navbar-toggler align-self-center text-white" type="button" data-toggle="minimize">
          <span class="ti-view-list"></span>
        </button>


        <!-- <ul class="navbar-nav mr-lg-2">
          <li class="nav-item nav-search d-none d-lg-block">
            <div class="input-group">
              <div class="input-group-prepend hover-cursor" id="navbar-search-icon">
                <span class="input-group-text" id="search">
                  <i class="ti-search"></i>
                </span>
              </div>
              <input type="text" class="form-control" id="navbar-search-input" placeholder="Search now" aria-label="search" aria-describedby="search">
            </div>
          </li>
        </ul> -->


        <?php 
        $query1="SELECT * FROM `e_dfo` WHERE `id`='$division_id'";
        $query_con1=mysqli_query($con, $query1);
        $dfetch1=mysqli_fetch_array($query_con1);
        ?>
        <ul class="navbar-nav navbar-nav-right" style="height: 10vh;">
          <li class="nav-item nav-profile dropdown">
            <h4 class="text-white" style="font-family: 'Roboto Condensed', sans-serif;"><?php echo $dfetch1['dfo_name']; ?></h4>&nbsp;&nbsp;
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <!-- <i class="ti-user icon-md text-white"></i> -->
              <i class="fa-regular fa-user fa-2x" style="color: white;"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown rounded-bottom" aria-labelledby="profileDropdown">
              <a href="logout.php" class="dropdown-item">
                <i class="ti-power-off text-primary"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="ti-view-list"></span>
        </button>
      </div>
    </nav>