<?php 
include('header.php');
include('topnav.php');
include('menu.php');
?>

<div class="main-panel">
<div class="content-wrapper" style="background-color: white;">
<div class="row">
<div class="col-md-12 grid-margin">
<center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>
<div class="d-flex justify-content-between align-items-center">
<!-- <div>
<h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Daily Elephant Movement Reports</h3>
</div> -->
</div>
</div>
</div>
<!-- ===========Search=========== -->
<form action="" method="POST" enctype="multipart/form-data">
<div class="col-md-12 m-0 p-3 border border-2 border-muted rounded">
<h5 style="font-family: 'Roboto Condensed', sans-serif;" align="center"><b>Search Your Report Date to Date :</b></h5>
<hr/>
<div class="row">
<div class="col">
<select name="division_id" class="form-control rounded">
<option value="">-- Select Division --</option>
<?php 
$query="SELECT id,dfo_name FROM `e_dfo` where `id`='18' ORDER BY `id` ASC";
$result=mysqli_query($con,$query);
while($rows=mysqli_fetch_array($result)){
?>
<option value="<?php echo $rows['id']; ?>"><?php echo $rows['dfo_name']; ?></option>
<?php } ?>
</select>
</div>
<div class="col">
<select name="range_id" class="form-control rounded">
<option value="">-- Select Range --</option>
<?php 
$query="SELECT * FROM `e_range` ORDER BY `r_id` ASC";
$result=mysqli_query($con,$query);
while($rows=mysqli_fetch_array($result)){
?>
<option value="<?php echo $rows['r_id']; ?>"><?php echo $rows['rangename']; ?></option>
<?php } ?>
</select>
</div>
<div class="col">
<input type="date" name="starting_date" class="form-control rounded" <?php if(isset($_REQUEST['division_search'])){ ?> value="<?php echo $_REQUEST['starting_date']; ?>" <?php } ?> required>
</div>
<i><b>to</b></i>
<div class="col">
<input type="date" name="ending_date" class="form-control rounded" <?php if(isset($_REQUEST['division_search'])){ ?> value="<?php echo $_REQUEST['ending_date']; ?>" <?php } ?> required>
</div>
<div class="col">
<button type="submit" name="division_search" class="btn text-white" style="background-color: #4d9900;">Search</button>
</div>
</div>
</div>
</form>
<!-- ============================ -->
<?php 
if(isset($_REQUEST['division_search'])){
$starting_date=$_REQUEST['starting_date'];
$ending_date=$_REQUEST['ending_date'];
$marged_elephant_number=0;
?>
<table class="table-bordered mt-4" cellspacing="0" cellpadding="0" width="100%" style="font-weight: bold;"> 
  
<tr style="background-color: #77b300; font-family: 'Roboto Condensed', sans-serif; font-weight: bold;">
<td style="width :10%;"><p align="center">Date</p></td>
<td style="width :13%;" valign="center"><p align="center">Division</p></td>
<td style="width :12%;" valign="center"><p align="center">Range</p></td>
<td style="width :19%;" valign="center"><p align="center">Mouza</p></td>
<td style="width :10%;" valign="center"><p align="center">No. of <br>Migratory<br> Elephants</p></td>
<td style="width :10%;" valign="center"><p align="center">No. of <br>Residential<br> Elephant </p></td>
<td style="width :9%;" valign="center"><p align="center">Total No. of<br> Elephant</p></td>
<td style="width :6%;" valign="center"><p align="center">Elephant<br> days<br> from<br> starting<br>to till date</p></td>
</tr>

<!-- //==================Date Distinct Start===================// -->

<?php 
$reng_id=$_REQUEST['range_id'];
$div_id=$_REQUEST['division_id'];
$query="SELECT DISTINCT `date_time` FROM `e_elephant_area` WHERE `date_time`>='$starting_date' and `date_time`<='$ending_date' ORDER BY `date_time` ASC";
$result=mysqli_query($con,$query);
$rows=mysqli_num_rows($result);
if($rows>0){
while($datafetch=mysqli_fetch_array($result)){
$distinct_date=$datafetch['date_time'];
$division_id=$datafetch['division_id'];
?>
<tr>
<td width="8%"><p align="center"><?php echo $distinct_date; ?></p></td>
<td valign="center" width="85%" colspan="7">


		<table  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
		<?php
		if($_REQUEST['division_id']!=''){
		$queryd="SELECT DISTINCT `division_id` FROM `e_elephant_area` WHERE `date_time`='$distinct_date' and  `date_time`='$distinct_date' and `division_id`='$div_id' ORDER BY `division_id` ASC";
		}else{
		$queryd="SELECT DISTINCT `division_id` FROM `e_elephant_area` WHERE `date_time`='$distinct_date' and  `date_time`='$distinct_date' ORDER BY `division_id` ASC";
		}
		$resultd=mysqli_query($con,$queryd);
		while($datafetchd=mysqli_fetch_array($resultd)){
		$distinct_division_id=$datafetchd['division_id'];
		?>
		<tr>
		<td width="15%">
		<p align="center">
		<?php $datafetch2=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_dfo` WHERE `id`='$distinct_division_id'"));
		echo $datafetch2['dfo_name'];
		?>
		</p>
		</td>
		
				<td width="70%">
				
						<table width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
						<?php
						if($_REQUEST['range_id']!=''){
						$queryd1="SELECT DISTINCT `range_id` FROM `e_elephant_area` WHERE `division_id`='$distinct_division_id' and `date_time`='$distinct_date' and `range_id`='$reng_id' ORDER BY `range_id` ASC";
						}else{
						$queryd1="SELECT DISTINCT `range_id` FROM `e_elephant_area` WHERE `division_id`='$distinct_division_id' and `date_time`='$distinct_date' ORDER BY `range_id` ASC";
						}
						$resultd1=mysqli_query($con,$queryd1);
						while($datafetchd1=mysqli_fetch_array($resultd1)){
						$range_ids=$datafetchd1['range_id'];
						?>
						<tr>
						<td  width="20%">
						<p align="center">
						<?php $datafetch23=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_range` WHERE `r_id`='$range_ids'"));
						echo $datafetch23['rangename'];
						?>
						</p>
						</td>
						
						<td  width="80%">
									<table  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
									<?php
									$queryd12="SELECT DISTINCT `mouza_id` FROM `e_elephant_area` WHERE `range_id`='$range_ids' and `date_time`='$distinct_date' ORDER BY `mouza_id` ASC";
									$resultd12=mysqli_query($con,$queryd12);
									while($datafetchd12=mysqli_fetch_array($resultd12)){
									$mouza_ids=$datafetchd12['mouza_id'];
									?>
									<tr>
									<td width="40%">
									<p align="center">
									<?php $datafetch24=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_mapping_table` WHERE `m_id`='$mouza_ids'"));
									echo $datafetch24['mouza_name'];
									?>
									</p>
									</td>
									
									<td width="20%"><p align="center">
									<?php $datafetch26=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_elephant_area` WHERE `mouza_id`='$mouza_ids' and `date_time`='$distinct_date'"));
									echo $datafetch26['title_one'];
									$title_one = $datafetch26['title_one'];
									?></p></td>
									<td width="20%"><p align="center">
									<?php echo $datafetch26['title_two'];
									$title_two = $datafetch26['title_two'];
									?></p></td>
									<td width="20%"><p align="center"><?php 
									$total_ele=$title_one+$title_two;
									echo $total_ele;
									$total_elephant += $title_one + $title_two;
									?></p></td>
									</tr>       
									<?php  } ?>
									</table>
						
						</td>
						
						</tr>       
						<?php  } ?>
						
						<tr class="bg-warning">
						<td align="right" colspan="2"> <strong> Total : <?php
						
if($_REQUEST['range_id']!=''){											
$querysg = ("SELECT SUM(title_one)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`='$distinct_date'  and `range_id`='$reng_id'"); 
	 }else{
$querysg = ("SELECT SUM(title_one)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`='$distinct_date'"); 
}

$resultsg = mysqli_query($con,$querysg) or die(mysqli_error());
while($rowssg = mysqli_fetch_array($resultsg))
{
$total1=$rowssg['SUM(title_one)']; 
}

if($_REQUEST['range_id']!=''){	
$querysg2 = ("SELECT SUM(title_two)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`='$distinct_date'  and `range_id`='$reng_id'"); 
	 }else{
$querysg2 = ("SELECT SUM(title_two)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`='$distinct_date'"); 	 
}
$resultsg2 = mysqli_query($con,$querysg2) or die(mysqli_error());
while($rowssg2 = mysqli_fetch_array($resultsg2))
{
$total2=$rowssg2['SUM(title_one)']; 
}	
 echo $total1+$total2;?></strong> </td>
						</tr>
						
						</table>
						
				</td>
		<td width="7%">
		<p align="center">
		<?php 								
$querysg2 = ("SELECT SUM(title_one)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`<='$ending_date'"); 	 
$resultsg2 = mysqli_query($con,$querysg2) or die(mysqli_error());
while($rowssg2 = mysqli_fetch_array($resultsg2))
{
$total12=$rowssg2['SUM(title_one)']; 
}
$querysg22 = ("SELECT SUM(title_two)FROM `e_elephant_area` where  `division_id`='$distinct_division_id' and `date_time`<='$ending_date'"); 	 
$resultsg22 = mysqli_query($con,$querysg22) or die(mysqli_error());
while($rowssg22 = mysqli_fetch_array($resultsg22))
{
$total22=$rowssg22['SUM(title_one)']; 
}	
 echo $total12+$total22;
		?>
		</p>
		</td>
		</tr>       
		<?php  } ?>
		</table>
		
		
</td>
</tr>
<?php  
}
}
?>
</table>
<?php  
}
?>
</div>
</div>
<?php include('footer.php'); ?>
