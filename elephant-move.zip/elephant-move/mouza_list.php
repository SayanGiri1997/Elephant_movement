<?php 
include('header.php');
include('topnav.php');
include('menu.php');
$range_id=$_REQUEST['range_id'];
$qus=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_range` WHERE `r_id`='$range_id'"));
$beat_id=$_REQUEST['beat_id']; 
$quss=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_beat` WHERE `b_id`='$beat_id'"));
					
?>

<div class="main-panel" >
        <div class="content-wrapper" style="background-color: white;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>

              <?php
              if(isset($_SESSION['letter1']))
              {
              ?>
              <div class="alert alert-success"><?php echo $_SESSION['letter1']; ?></span></div>
              <?php
              unset($_SESSION['letter1']);
              }
              ?>

              <?php
              if(isset($_SESSION['letter1']))
              {
              ?>
              <div class="alert alert-danger"><?php echo $_SESSION['letter2']; ?></span></div>
              <?php
              unset($_SESSION['letter1']);
              }
              ?>

              
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Division - <?php echo $dfetch1['dfo_name']; ?> > Range-<?php echo $qus['rangename'];?>  > Beat- <?php echo $quss['beat']; ?> > Mouza List</h4>
                </div>
                <!-- <div class="col-md-4">
                <div id="custom-search-input">
                <form action="" method="get" name="" enctype="multipart/form-data">
                <div class="input-group">
                    <input type="text" class="search-query form-control rounded border border-1 border-info" placeholder="Search The Mouza" name="value" style="font-family: 'Nova Round', cursive;" autocomplete="off" />
                    <span class="input-group-btn">
                        <button type="button" disabled>
                            <span class="fa fa-search"></span>
                        </button>
                    </span>
                </div>
                </form>
                </div></div> -->
              </div>
            </div>
          </div>
          <div class="row">
          <div class="col-md-12">

            <?php
              if(isset($_REQUEST['range_id']) && isset($_REQUEST['division_id']) && isset($_REQUEST['district_id']) && isset($_REQUEST['beat_id'])){
                $range_id=$_REQUEST['range_id'];
                $division_id=$_REQUEST['division_id'];
                $district_id=$_REQUEST['district_id'];
                $beat_id=$_REQUEST['beat_id'];
              }  
            ?>
            <form action="action/mouza_wise_elephant.php" method="POST" enctype="multipart/form-data">


              <!-- <div class="col-md-3" style="float: right;"><input type="date" class="form-control mb-1 border border-primary bg-info shadow" name="date[]" id="date[]"></div> -->
              <input type="hidden" name="range_id" value="<?php echo $range_id; ?>">
              <input type="hidden" name="division_id" value="<?php echo $division_id; ?>">
              <input type="hidden" name="district_id" value="<?php echo $district_id; ?>">
              <input type="hidden" name="beat_id" value="<?php echo $beat_id; ?>">

            <table class="table-bordered rounded" style="width: 100%;" id="myTable1">
              <thead>
              <tr align="center" class="text-white" style="background-color: #002966;">
                <td width="10%">Sl No.</td>
                <!-- <td width="10%">Checked</td> -->
                <td width="25%">Mouza Name</td>
                <td width="25%" class="border-0 p-2">No. of Migratory Elephants</td>
                <td width="25%" class="border-0 p-2">No. of Residential Elephant</td>
              </tr>
              </thead>

              <?php
              if(isset($_REQUEST['range_id']) && isset($_REQUEST['division_id']) && isset($_REQUEST['beat_id'])){
               $range_id=$_REQUEST['range_id'];
               $division_id=$_REQUEST['division_id'];
               $beat_id=$_REQUEST['beat_id'];
              }

              $date=date('Y-m-d');
              $query="SELECT * FROM `e_mapping_table` WHERE `division_id`='$division_id' and `range_id`='$range_id' and `beat_id`='$beat_id' order by `m_id` asc;";
              $result=mysqli_query($con,$query);
              $mouza=1;
              while($datafetch=mysqli_fetch_array($result)){
              ?>

              <?php
                $division_idd=$datafetch['division_id'];
                $range_idd=$datafetch['range_id'];
                $beatt_idd=$datafetch['beat_id'];
                $mouza_id=$datafetch['m_id'];
                $query11="SELECT * FROM `e_elephant_area` WHERE `division_id`='$division_idd' and `range_id`='$range_idd' and `beat_id`='$beatt_idd' and `mouza_id`='$mouza_id' and `date_time`='$date'";
                $result11=mysqli_query($con,$query11);
                $dtfetch=mysqli_fetch_array($result11);
              ?>

              <tbody>
              <tr align="center" style="font-family: 'Roboto Condensed', sans-serif; ">
                <td><b><?php echo $mouza; ?></b></td>
                <!-- <td><input type="checkbox" class="" name="checked[]" id="checked"></td> -->
                <td><b><?php echo $datafetch['mouza_name']; ?></b>

                <input type="hidden" name="mouza_id[]" value="<?php echo $datafetch['m_id']; ?>">
				</td>
                


                <td class="p-2">
                  <input type="text" class="form-control form-control-sm rounded-pill shadow border border-dark py-0" name="one[]" id="one[]" <?php if(isset($dtfetch['title_one'])){ ?>value="<?php echo $dtfetch['title_one'];?>" <?php }else{ ?>  <?php } ?> placeholder="Enter Value.." autocomplete="off" style="font-size:17px;">
                </td>

                <td class="p-2"><input type="text" class="form-control  form-control-sm rounded-pill shadow border border-dark py-0" name="two[]" id="two[]" <?php if(isset($dtfetch['title_two'])){ ?>value="<?php echo $dtfetch['title_two'];?>" <?php } else{ ?>  <?php  } ?> placeholder="Enter Value.." autocomplete="off" style="font-size:17px;"></td>

              
              </tr>
              </tbody>
              <?php
              $mouza++;
              }
              ?>
            </table>



             <div align="center" class="mt-2">

              <?php if(isset($dtfetch['id'])) { ?>
              <button type="submit" name="el_data_update" class="btn btn-primary mt-1 mb-1 rounded-pill">Update</button>
  
              <?php } else{ ?>
              <button type="submit" name="el_data_submit" class="btn btn-primary mt-1 mb-1 rounded-pill">Submit</button>
              <?php } ?>

                </div>

          </form>
          </div>
        </div>

        </div>
      </div>


<?php include('footer.php'); ?>
