<?php 
include('header.php');
include('topnav.php');
include('menu.php');
?>


<div class="main-panel">
        <div class="content-wrapper" style="background-color: white;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>
              <div class="d-flex justify-content-between align-items-center">

                <!-- <div>
                  <h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Daily Elephant Movement Reports</h3>
                </div> -->

              </div>
            </div>
          </div>

          <table class="table-bordered table-responsive" cellspacing="0" cellpadding="0" width="100%" style="font-weight: bold;">

  <tr style="background-color: #77b300; font-family: 'Roboto Condensed', sans-serif; font-weight: bold;">
    <td style="width :3%;"><p align="center">Date</p></td>
    <td style="width :6%;" valign="center"><p align="center">Division</p></td>
    <td style="width :8%;" valign="center"><p align="center">Range</p></td>
    <td style="width :8%;" valign="center"><p align="center">No. of <br>Migratory<br> Elephants</p></td>
    <td style="width :8%;" valign="center"><p align="center">No. of <br>Residential<br> Elephant </p></td>
    <td style="width :8%;" valign="center"><p align="center">Total No. of<br> Elephant</p></td>
    <td style="width :6%;" valign="center"><p align="center">Elephant<br> days<br> starting<br> from<br> 10.01.2024<br> to till date</p></td>
  </tr>
  
  
  <tr>
    <td width="92"><p align="center">10/01/2024</p></td>
    <td colspan="6" valign="center">
  
  <table border="1" cellspacing="0" cellpadding="0" align="left"  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
      <tr>
        <td width="184"><p align="center">DIVISION 1</p></td>
    
        <td width="1121" valign="center">
    <table border="1" cellspacing="0" cellpadding="0" align="left"  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
          <tr>
            <td width="104"><p align="center">Range name 1</p></td>
            <td width="104"><p align="center">56</p></td>
            <td width="104"><p align="center">88</p></td>
            <td width="104"><p align="center">54</p></td>
          </tr>
       <tr>
            <td width="104"><p align="center">Range name 2</p></td>
            <td width="104"><p align="center">56</p></td>
            <td width="104"><p align="center">88</p></td>
            <td width="104"><p align="center">54</p></td>
          </tr>
      
       <tr>
            <td width="104"><p align="center">Range name 3</p></td>
            <td width="104"><p align="center">56</p></td>
            <td width="104"><p align="center">88</p></td>
            <td width="104"><p align="center">54</p></td>
          </tr>
      
          <tr>
            <td width="417" colspan="4" style="background-color: #77b300;" class="pr-2 pt-1"><p align="right">Total - 36</p></td>
          </tr>
      
      
        </table>
    </td>
        <td width="207" style="background-color: #b3f0ff;"><p align="center">1250</p></td>
      </tr>
      <tr>
        <td width="184"><p align="center">DIVISION 2</p></td>
        <td width="1121" valign="top">
    
    <table border="1" cellspacing="0" cellpadding="0" align="left"  width="100%" style="font-family: 'Roboto Condensed', sans-serif;">
    
          <tr>
            <td width="104"><p align="center">Range name 4</p></td>
            <td width="104"><p align="center">45</p></td>
            <td width="104"><p align="center">25</p></td>
            <td width="104"><p align="center">55</p></td>
          </tr>
       <tr>
            <td width="104"><p align="center">Range name 5</p></td>
            <td width="104"><p align="center">56</p></td>
            <td width="104"><p align="center">88</p></td>
            <td width="104"><p align="center">54</p></td>
          </tr>
      
       <tr>
            <td width="104"><p align="center">Range name 6</p></td>
            <td width="104"><p align="center">56</p></td>
            <td width="104"><p align="center">88</p></td>
            <td width="104"><p align="center">54</p></td>
          </tr>
      
      
          <tr>
            <td width="417" colspan="4" style="background-color: #77b300;" class="pr-2 pt-1"><p align="right">Total - 37</p></td>
          </tr>
      
        </table>
    </td>
        <td width="207" style="background-color: #80e5ff;"><p align="center">5241</p></td>
      </tr>
    </table>
  </td>
  </tr>
</table>



        </div>
      </div>


<?php include('footer.php'); ?>
