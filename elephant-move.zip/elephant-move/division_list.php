<?php 
error_reporting(0);
include('header.php');
include('topnav.php');
include('menu.php');
?>

<?php 
if($_SESSION['session_id']){
  $division_id=$_SESSION['session_id'];
}
?>

<div class="main-panel">
        <div class="content-wrapper" style="background-color: white;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <center><h3 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">West Bengal Forest Department (Elephant Movement)</h3></center><hr class="w-100"><br>
              <div class="d-flex justify-content-between align-items-center">

                <div>
                  <h4 class="font-weight-bold mb-0" style="color: #005cdc; font-family: 'Roboto Condensed', sans-serif;">Division  List</h4>
                </div>

                <!-- <div class="col-md-4">
                <div id="custom-search-input">
                <form action="range_list.php" method="POST" enctype="multipart/form-data">
                <div class="input-group">
                    <input type="text" class="search-query form-control rounded border border-1 border-info" placeholder="Search The Range" name="range_search" style="font-family: 'Nova Round', cursive;" autocomplete="off" />
                    <span class="input-group-btn">
                        <button type="button" disabled>
                            <span class="fa fa-search"></span>
                        </button>
                    </span>
                </div>
                </form>
                </div></div> -->
                
              </div>
            </div>
          </div>

        
          <div class="row">
              <?php 
              $query="SELECT DISTINCT `division_id` FROM  `e_mapping_table`";
              $result=mysqli_query($con, $query);
			  $i=1;
			  if(mysqli_num_rows($result)>0){
              while($dfetch=mysqli_fetch_array($result)){
			
              ?>

              <div class="col-md-3 grid-margin">
              <div class="card" style="background-color: #0047b3; border-radius: 10px;">
			   <?php
			  $division_id=$dfetch['division_id'];
			  $quss=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_mapping_table` WHERE `division_id`='$division_id'"));
			  $district_id=$quss['district_id'];
			  ?>
                <a href="range_list.php?district_id=<?php echo $district_id; ?>&division_id=<?php echo $division_id; ?>" style="text-decoration: none;">
                <div class="card-body py-4">

                  <!-- <p class="card-title text-md-center text-xl-left">no of Beats - <?php //echo $num_rows; ?></p> -->
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h4 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 text-white"><b><?php 
					$qus=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_dfo` WHERE `id`='$division_id'"));
					echo $qus['dfo_name'];  ?></b></h4>
                    <i class="ti-calendar icon-md text-white mb-0 mb-md-3 mb-xl-0"></i>
                  </div>  
                </div>
                </a>
              </div>
              </div>
   
<?php 
$i++;
}
}
?>

       </div>

        </div>
      </div>
<?php include('footer.php'); ?>
