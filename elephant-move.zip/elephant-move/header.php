<?php include('lib/configur.php'); 

if(!isset($_SESSION['session_id']) and !isset($_SESSION['token_id']))
    {
      header('location:index.php');
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>West Bengal Forest Department :: Elephant Movement</title>

  <!-- ================Css================== -->
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
  <!-- <link rel="stylesheet" href="bootstrap-5.0.2/css/bootstrap.css"> -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="shortcut icon" href="images/favicon.png" />

  <!-- ================Js================== -->
  <!-- <script src="bootstrap-5.0.2/js/bootstrap.js"></script> -->

  <!-- ===============icon==================== -->
  <link rel="stylesheet" href="fontawesome-6.5.1/css/all.css">
  <script src="fontawesome-6.5.1/js/all.js"></script>
</head>
<body>