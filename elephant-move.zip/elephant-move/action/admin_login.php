<?php 
include("../lib/configur.php");

if(isset($_POST['elephant_submit'])){
	$el_user=$_POST['el_user'];
	$el_pwd=md5($_POST['el_pwd']);

	$query="SELECT * FROM `e_dfo` WHERE `dfo_email`='$el_user' and `dfo_pass`='$el_pwd'";
	$query_con=mysqli_query($con, $query);
	$dfetch=mysqli_fetch_array($query_con);

	if($dfetch['id']){

		$_SESSION['msg11']="Login Successfull....";
		$_SESSION['session_id']=$dfetch['id'];
		$_SESSION['division_name']=$dfetch['dfo_name'];
		$_SESSION['token_id']=rand(1000,9999);
    	header("location:../dashboard.php?success");
	}else{
		$_SESSION['msg22']='<div class="alert alert-warning" role="alert">
 User id or Password not matched....
</div>';
    	header("location:../index.php?error");
	}
}
?>