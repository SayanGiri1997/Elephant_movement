<?php 
include("../lib/configur.php");

if(isset($_POST['el_data_submit'])){
	$range_id=$_REQUEST['range_id'];
    $division_id=$_REQUEST['division_id'];
    $district_id=$_REQUEST['district_id'];
    $beat_id=$_REQUEST['beat_id'];
    $date=date('Y-m-d');
    $time_stamp=date('Y-m-d h:i:s');
    $query="SELECT * FROM `e_mapping_table` WHERE `district_id`='$district_id' and `division_id`='$division_id' and `range_id`='$range_id' and `beat_id`='$beat_id'";
    $result=mysqli_query($con, $query);
    $dftch1=mysqli_fetch_array($result);
    $mouza_count=mysqli_num_rows($result);
    if($result){
    	for($i=0; $i<$mouza_count; $i++){
		$mouza_id=$_REQUEST['mouza_id'][$i];
		$one=$_REQUEST['one'][$i];
    	$two=$_REQUEST['two'][$i];
		if($one>0){
		$querym="SELECT * FROM `e_mapping_table` WHERE `district_id`='$district_id' and `division_id`='$division_id' and `range_id`='$range_id' and `beat_id`='$beat_id' and `m_id`='$mouza_id'";
    	$resultm=mysqli_query($con, $querym);
    	$datafetchm=mysqli_fetch_array($resultm);
    	$lat_long=$datafetchm['lat_long'];	
		
	$qurm=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `e_elephant_area` WHERE `date_time`='$date' and  `mouza_id`='$mouza_id'"));
	 if($qurm['mouza_id']){
	 
	   $query1="UPDATE `e_elephant_area` SET `district_id`='$district_id', `division_id`='$division_id', `range_id`='$range_id', `beat_id`='$beat_id', `mouza_id`='$mouza_id', `title_one`='$one', `title_two`='$two', `date_time`='$date', `time_stamp`='$time_stamp', `lat_long`='$lat_long' WHERE `mouza_id`='$mouza_id' and `date_time`='$date'";
        $result=mysqli_query($con, $query1);
		}else{
		
		$query1="INSERT INTO `e_elephant_area`(`district_id`, `division_id`, `range_id`, `beat_id`, `mouza_id`, `title_one`, `title_two`, `date_time`, `time_stamp`, `lat_long`) VALUES ('$district_id','$division_id','$range_id','$beat_id','$mouza_id','$one','$two','$date','$time_stamp','$lat_long')";
		    	$result=mysqli_query($con, $query1);
				
			}	
				
    	if($result){
             $_SESSION['letter1']="Submit Successfully";
                header("location:../mouza_list.php?range_id=$range_id&district_id=$district_id&division_id=$division_id&beat_id=$beat_id&Success");
                }else{ 
              $_SESSION['letter2']="Data Insert Error";
                header("location:../mouza_list.php?range_id=$range_id&district_id=$district_id&division_id=$division_id&beat_id=$beat_id&err");
             	}
			}
    	} 
    }
}

// Update==========================
//if(isset($_POST['el_data_update'])){
//    $range_id=$_REQUEST['range_id'];
//    $division_id=$_REQUEST['division_id'];
//    $district_id=$_REQUEST['district_id'];
//    $beat_id=$_REQUEST['beat_id'];
//    $date=date('Y-m-d');
//    $time_stamp=date('Y-m-d h:i:s');
//    $query="SELECT * FROM `e_mapping_table` WHERE `district_id`='$district_id' and `division_id`='$division_id' and `range_id`='$range_id' and `beat_id`='$beat_id'";
//    $result=mysqli_query($con, $query);
//    $dftch1=mysqli_fetch_array($result);
//    $mouza_count=mysqli_num_rows($result);
//    if($result){
//        for($i=0; $i<$mouza_count; $i++){
//        $mouza_id=$_REQUEST['mouza_id'][$i];
//        $one=$_REQUEST['one'][$i];
//        $two=$_REQUEST['two'][$i];
//        $checked=$_REQUEST['checked'][$i];
//		if($one>0){
//        $querym="SELECT * FROM `e_mapping_table` WHERE `district_id`='$district_id' and `division_id`='$division_id' and `range_id`='$range_id' and `beat_id`='$beat_id' and `m_id`='$mouza_id'";
//        $resultm=mysqli_query($con, $querym);
//        $datafetchm=mysqli_fetch_array($resultm);
//        $lat_long=$datafetchm['lat_long'];
//  $query1="UPDATE `e_elephant_area` SET `district_id`='$district_id', `division_id`='$division_id', `range_id`='$range_id', `beat_id`='$beat_id', `mouza_id`='$mouza_id', `title_one`='$one', `title_two`='$two', `date_time`='$date', `time_stamp`='$time_stamp', `lat_long`='$lat_long' WHERE `mouza_id`='$mouza_id' and `date_time`='$date'";
//        $result=mysqli_query($con, $query1);
//        if($result){
//             $_SESSION['letter1']="Update Successfully";
//                header("location:../mouza_list.php?range_id=$range_id&district_id=$district_id&division_id=$division_id&beat_id=$beat_id&Success");
//                }else{ 
//              $_SESSION['letter2']="Data Update Error";
//                header("location:../mouza_list.php?range_id=$range_id&district_id=$district_id&division_id=$division_id&beat_id=$beat_id&err");
//             }
//		  }
//   	   } 
//    }
//}
?>